import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

interface Task {
  id: string;
  title: string;
  description?: string;
  completed: boolean;
}

interface Props {
  task: Task;
  onRemove: () => void;
  onToggleCompletion: () => void;
}

const TaskItem: React.FC<Props> = ({ task, onRemove, onToggleCompletion }) => {
  return (
    <View style={styles.item}>
      <TouchableOpacity onPress={onToggleCompletion} style={styles.checkbox}>
        <View style={[styles.checkmark, task.completed && styles.checked]}>
          {task.completed && <Text style={styles.checkmarkText}>✔</Text>}
        </View>
      </TouchableOpacity>
      <View style={styles.content}>
        <Text style={[styles.title, task.completed && styles.completed]}>{task.title}</Text>
        {task.description && <Text style={styles.description}>{task.description}</Text>}
      </View>
      <TouchableOpacity onPress={onRemove} style={styles.removeButton}>
        <Text style={styles.removeText}>Remove</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    marginBottom: 10,
    backgroundColor: '#ffffff',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  checkbox: {
    marginRight: 15,
  },
  checkmark: {
    width: 24,
    height: 24,
    borderWidth: 2,
    borderColor: '#4A90E2',
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checked: {
    backgroundColor: '#4A90E2',
  },
  checkmarkText: {
    color: '#fff',
    fontSize: 18,
  },
  content: {
    flex: 1,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  completed: {
    textDecorationLine: 'line-through',
    color: '#888',
  },
  description: {
    fontSize: 14,
    color: '#666',
    marginTop: 5,
  },
  removeButton: {
    padding: 10,
  },
  removeText: {
    color: '#E57373',
    fontWeight: '600',
  },
});

export default TaskItem;

